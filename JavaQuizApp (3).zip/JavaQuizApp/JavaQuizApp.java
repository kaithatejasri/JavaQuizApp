import java.util.*;

public class JavaQuizApp {

    static class Question {
        String question;
        String[] options;
        char answer;

        Question(String question, String[] options, char answer) {
            this.question = question;
            this.options = options;
            this.answer = answer;
        }
    }

    static Scanner sc = new Scanner(System.in);
    static List<Question> theoryBank = new ArrayList<>();

    static void loadQuestions() {
        theoryBank.add(new Question("What is JVM?", new String[]{"Java Virtual Machine", "Java Vendor Machine", "Java Visual Mode", "Java Verified Mode"}, 'a'));
        theoryBank.add(new Question("Which keyword is used to inherit a class?", new String[]{"this", "extends", "super", "implements"}, 'b'));
        theoryBank.add(new Question("Which is not a primitive data type?", new String[]{"int", "float", "String", "char"}, 'c'));
        theoryBank.add(new Question("What is the default value of boolean?", new String[]{"true", "false", "null", "0"}, 'b'));
        theoryBank.add(new Question("Which loop checks condition after execution?", new String[]{"for", "while", "do-while", "None"}, 'c'));

        theoryBank.add(new Question("Which class is automatically imported?", new String[]{"java.util", "java.io", "java.lang", "java.net"}, 'c'));
        theoryBank.add(new Question("What does OOP stand for?", new String[]{"Object Over Programming", "Object Oriented Programming", "Only One Program", "Overloaded Output Program"}, 'b'));
        theoryBank.add(new Question("Which keyword is used to call parent constructor?", new String[]{"super", "this", "base", "inherit"}, 'a'));
        theoryBank.add(new Question("Which of these is not a loop?", new String[]{"for", "while", "do", "if"}, 'd'));
        theoryBank.add(new Question("Default value of int?", new String[]{"0", "null", "undefined", "1"}, 'a'));

        theoryBank.add(new Question("What is the size of char in Java?", new String[]{"1 byte", "2 bytes", "4 bytes", "Depends"}, 'b'));
        theoryBank.add(new Question("Which keyword defines constant?", new String[]{"static", "final", "const", "constant"}, 'b'));
        theoryBank.add(new Question("Which access modifier is most restrictive?", new String[]{"private", "protected", "public", "default"}, 'a'));
        theoryBank.add(new Question("Java variables are case sensitive?", new String[]{"No", "Yes", "Sometimes", "Only constants"}, 'b'));
        theoryBank.add(new Question("Which is not an access modifier?", new String[]{"private", "public", "protected", "static"}, 'd'));

        theoryBank.add(new Question("Which keyword is used for interface implementation?", new String[]{"extends", "implements", "interface", "inherit"}, 'b'));
        theoryBank.add(new Question("Which operator compares values?", new String[]{"=", "==", "!=", "Both b and c"}, 'd'));
        theoryBank.add(new Question("Which package is default in Java?", new String[]{"java.util", "java.io", "java.lang", "None"}, 'c'));
        theoryBank.add(new Question("Which one is not exception handling keyword?", new String[]{"throw", "catch", "throws", "error"}, 'd'));
        theoryBank.add(new Question("Which statement skips iteration?", new String[]{"break", "exit", "continue", "return"}, 'c'));

        theoryBank.add(new Question("Which block always executes in exception?", new String[]{"try", "catch", "finally", "throw"}, 'c'));
        theoryBank.add(new Question("What is returned by main()?", new String[]{"void", "int", "char", "None"}, 'a'));
        theoryBank.add(new Question("Which symbol ends a statement?", new String[]{";", ".", ":", "}"}, 'a'));
        theoryBank.add(new Question("Which class is used for input?", new String[]{"Scanner", "Input", "Buffer", "Stream"}, 'a'));
        theoryBank.add(new Question("Which is correct method declaration?", new String[]{"void main()", "public static void main(String[] args)", "main()", "int Main"}, 'b'));

        theoryBank.add(new Question("Which memory holds static variables?", new String[]{"Heap", "Stack", "Method Area", "Register"}, 'c'));
        theoryBank.add(new Question("JVM is part of?", new String[]{"JDK", "JRE", "JIT", "JAR"}, 'b'));
        theoryBank.add(new Question("Which keyword defines a method that cannot be overridden?", new String[]{"static", "const", "final", "override"}, 'c'));
        theoryBank.add(new Question("Which is used to stop loop?", new String[]{"break", "exit", "continue", "stop"}, 'a'));
        theoryBank.add(new Question("What does System.out.println() do?", new String[]{"Print line", "Print variable", "Run system", "None"}, 'a'));
    }

    static int askQuestions(List<Question> pool, int startIndex) {
        int score = 0;
        for (int i = 0; i < 5; i++) {
            Question q = pool.get(startIndex + i);
            System.out.println("\nQ" + (i + 1) + ": " + q.question);
            for (int j = 0; j < q.options.length; j++) {
                System.out.println((char) ('a' + j) + ") " + q.options[j]);
            }

            System.out.print("Your answer: ");
            String ans = sc.nextLine().toLowerCase();

            if (ans.length() == 1 && ans.charAt(0) == q.answer) {
                System.out.println("✅ Correct! " + q.answer + ") " + q.options[q.answer - 'a']);
                score++;
            } else {
                System.out.println("❌ Wrong!");
                System.out.println("✔ Correct Answer: " + q.answer + ") " + q.options[q.answer - 'a']);
            }
        }
        return score;
    }

    public static void main(String[] args) {
        loadQuestions();
        int round = 1;
        int maxRounds = 6;
        int totalScore = 0;

        while (round <= maxRounds) {
            System.out.println("\n🎯 Round " + round + " of " + maxRounds);
            int start = (round - 1) * 5;
            int score = askQuestions(theoryBank, start);
            double percent = score * 20;

            System.out.println("Round Score: " + score + "/5 → " + percent + "%");

            if (percent >= 40) {
                totalScore += score;
                if (round == maxRounds) {
                    System.out.println("✅ PASSED! That was the final round!");
                } else {
                    System.out.println("✅ PASSED! Moving to next round...");
                }
                round++;
            } else {
                System.out.println("❌ FAILED! Retaking round...");
            }
        }

        System.out.println("\n🎉 CONGRATULATIONS! You cleared all 6 rounds!");
        System.out.println("🏁 Final Score: " + totalScore + "/30");
    }
}