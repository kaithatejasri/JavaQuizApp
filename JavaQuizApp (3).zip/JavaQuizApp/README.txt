JavaQuizApp – Core Java Console MCQ App

📌 Description:
An interactive Java console-based quiz game that tests your knowledge on Core Java topics such as OOP, variables, loops, exceptions, JVM, arrays, and more.

🛠 Built With:
- Java (Core)
- Scanner Class
- OOP Concepts
- Loops and Conditionals

🎯 Features:
- 6 rounds, 5 questions each (30 total)
- No repeated questions
- 40% score required to pass each round
- Retake round on fail
- Final score display and congratulations message
- Fully offline: works in CMD, Sublime Text, VS Code, and JavaDroid

▶️ How to Run:
1. Open Command Prompt in the project folder  
2. Compile the file:  
   javac JavaQuizApp.java  
3. Run the program:  
   java JavaQuizApp

📁 Folder Structure:
JavaQuizApp/
├── JavaQuizApp.java
├── JavaQuizApp.class
├── JavaQuizApp$Question.class
├── README.txt

👤 Author: Kaitha Teja Sri  
📎 Project Link: Available in LinkedIn description 